# GPT Chatbot with Memory using LangChain

## Features
- Remembers previous messages using ConversationBufferMemory
- Easily extendable with tools, retrieval, agents, and more

## Setup Instructions

1. **Create virtual environment**:
```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

2. **Install dependencies**:
```bash
pip install -r requirements.txt
```

3. **Set your OpenAI API key**:
Edit the `.env` file and add your OpenAI key:
```
OPENAI_API_KEY=your_openai_api_key_here
```

4. **Run the chatbot**:
```bash
python main.py
```

Type `exit` to stop the chatbot.
