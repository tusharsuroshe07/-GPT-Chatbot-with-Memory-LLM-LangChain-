from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationChain
from memory.memory_handler import get_memory
import os
from dotenv import load_dotenv

load_dotenv()

def create_agent():
    llm = ChatOpenAI(temperature=0.7, model="gpt-3.5-turbo", openai_api_key=os.getenv("OPENAI_API_KEY"))
    memory = get_memory()
    return ConversationChain(llm=llm, memory=memory)
