from agent.chatbot_agent import create_agent

def run_chat():
    agent = create_agent()
    print("🤖 GPT Chatbot with Memory. Type 'exit' to quit.\n")
    while True:
        query = input("You: ")
        if query.lower() == "exit":
            break
        response = agent.run(query)
        print("Bot:", response)

if __name__ == "__main__":
    run_chat()
